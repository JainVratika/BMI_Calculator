import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import Bmi_calculator from "./Bmi_calculator";

const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

root.render(
  <StrictMode>
    <Bmi_calculator />
  </StrictMode>
);
