import "./styles.css";
import { useState } from "react";

export default function Bmi_calculator() {
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [bmi, setBmi] = useState("");
  const [message, setMessage] = useState("");

  const calcBmi = (e) => {
    e.preventDefault();
    if (weight === 0 || height === 0 || isNaN(weight)) {
      alert("Please enter a valid weight and height");
    } else {
      const bmi = weight / (height * height);
      setBmi(bmi.toFixed(1));
      if (bmi < 18.5) {
        setMessage("You are underweight");
      } else if (bmi >= 18.5 && bmi < 25) {
        setMessage("You are healthy");
      } else {
        setMessage("You are overweight");
      }
    }
  };

  const reload = () => {
    window.location.reload();
  };

  return (
    <div className="app">
      <div className="container">
        <h1 className="heading">BMI Calculator</h1>
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPvtPtqyi49Hzzaj6XU-SaxYjQc6ABM_9wO6hl31bc-UsX214KJ8lGc2UPT2toD4I1ZVM&usqp=CAU" />
        <form onSubmit={calcBmi}>
          <div>
            <label>Weight (Kg)</label>
            <input
              type="text"
              placeholder="Enter the weight value"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
            />
          </div>
          <div>
            <label>Height (m)</label>
            <input
              type="text"
              placeholder="Enter the height value"
              value={height}
              onChange={(e) => setHeight(e.target.value)}
            />
          </div>
          <div>
            <button className="btn" type="submit">
              Submit
            </button>
            <button className="btn btn-outline" onClick={reload} type="button">
              Reload
            </button>
          </div>
          <div className="center">
            <h3>Your BMI is: {bmi}</h3>
            <p>{message}</p>
          </div>
        </form>
      </div>
    </div>
  );
}
